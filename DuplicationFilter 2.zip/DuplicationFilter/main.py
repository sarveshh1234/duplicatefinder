"""
Author:
Mrvishal2k2
mrvishal2k2@pm.me

I did everything in 1 file coz its for repl hosting
"""
import asyncio
import logging
import os
import re
import traceback
from datetime import datetime
from logging.handlers import RotatingFileHandler
from difflib import SequenceMatcher
import motor.motor_asyncio
import nest_asyncio
import pyrogram
from dateutil import tz
from pyrogram import Client
from pyrogram import filters
from pyrogram.errors import FloodWait
from unshortenit import UnshortenIt
from urllib.parse import urlparse, parse_qs

# imports

LOCALDB = {}
# better
nest_asyncio.apply()

# configs
API_ID = "15425332"
API_HASH = "af903fd0febb48b8edcbf648f372fe08"
BOT_TOKEN = "5579819034:AAHtgVBVe7od1cKHDyPv5J0bc2j7lU9oEpQ"
OWNER = "881186666" # "498415794" BOT NOTIFY HERE AFTER POST REMOVE
# mongodb url
MONGO_URL = "mongodb+srv://duplicheck:duplicheck123@cluster0.i6pocix.mongodb.net/?retryWrites=true&w=majority"
from_channel = [-1001388213936, -1001786906074]  # 2nd is test channel
GROUP = "-1001754680951"  # sends log here
AUTH_USERS = [881186666, 498415794]  # who can use bot
MATCH_PCENT = 30 # if 30% match delete
# unshort
unshortener = UnshortenIt(default_timeout=20)

# logging more
if os.path.exists("Log.txt"):
    with open("Log.txt", "r+") as f_d:
        f_d.truncate(0)

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%d-%b-%y %H:%M:%S",
    handlers=[
        RotatingFileHandler("Log.txt", maxBytes=2097152000, backupCount=10),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)

# log spammers
logging.getLogger("pyrogram").setLevel(logging.WARNING)
logging.getLogger("pyrogram.parser").setLevel(logging.CRITICAL)
logging.getLogger("pyrogram.session").setLevel(logging.CRITICAL)
logging.getLogger("urllib3.connectionpool").setLevel(logging.CRITICAL)

# client start
Bot = Client(
    name="Robot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    sleep_threshold=15,
)


class Database:

    def __init__(self):
        self._client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
        self.db = self._client["duplicheck"]
        self.col = self.db.setting

        self.cache = {}  # local cache to decrease db call

    async def createcollection(self):
        a = await self.col.find_one({"type": "session"})
        a = bool(a)
        if not a:
            self.col.insert_one({"type": "session", "sessionstring": ""})
        b = await self.col.find_one({"type": "timing"})

        b = bool(b)
        if not b:
            self.col.insert_one({"type": "timing", "timing": 43200})

    async def getSession(self):
        user = self.cache.get("sessionstring")
        if user is not None:
            return user
        user = await self.col.find_one({"type": "session"})
        data = user.get("sessionstring", "")
        self.cache["sessionstring"] = data
        return data

    async def gettiming(self):
        user = self.cache.get("timing")
        if user is not None:
            return user
        user = await self.col.find_one({"type": "timing"})
        data = user.get("timing", 43200)
        self.cache["timing"] = int(data)
        return int(data)

    async def update_session(self, sessionstring):
        self.cache["sessionstring"] = sessionstring
        await self.col.update_one({"type": "session"},
                                  {"$set": {
                                      "sessionstring": sessionstring
                                  }})

    async def update_timing(self, timing):
        self.cache["timing"] = int(timing)
        await self.col.update_one({"type": "timing"},
                                  {"$set": {
                                      "timing": timing
                                  }})


db = Database()


async def unshorten(url):
    try:
        expanded_url = unshortener.unshorten(url, unshorten_nested=True)
    except Exception as e:
        logger.error(f"Unshorten failed using normal link {e}")
        return url
    return expanded_url


async def notify(client,
                 message,
                 newmsg="",
                 link="",
                 isdeleted="IT IS AUTO DELETED",
                 matchpcent="100",
                 tousr=True,
                 togroup=True):

    x = await message.copy(int(GROUP))

    msg = f"""**Alert**
There might be a duplicate deal posted.
NOTE: {isdeleted}

Posted message (deleted): {newmsg}
Old matched message: {LOCALDB[link]['messagelink']}
Oldmsg Posttime: {LOCALDB[link]['time']}
Message Content: {x.link}
Matching percentage: {matchpcent}%

"""
    if message.author_signature:
        msg += f"\nPosted by {message.author_signature}"

    try:
        if togroup:
            await client.send_message(chat_id=int(GROUP), text=msg)
    except FloodWait as e:
        await asyncio.sleep(e.value)
        return await notify(client, message, newmsg, link, tousr, togroup)

    except Exception as e:
        logger.error(f"Failed to notify group {e}")
        pass

    await asyncio.sleep(1)

    try:
        await client.send_message(chat_id=OWNER, text=msg)
    except FloodWait as e:
        await asyncio.sleep(e.value)
        return await notify(client,
                            message,
                            newmsg,
                            link,
                            tousr=tousr,
                            togroup=False)
    except Exception as e:
        logger.error(f"Failed to notify user {e}")
        pass


async def removefromlocaldb(link):
    STORETIME = await db.gettiming()
    await asyncio.sleep(int(STORETIME))
    LOCALDB.pop(link)

def similar(a, b): 
    ratio = SequenceMatcher(None, a, b).ratio()
    match = int(ratio*100)
    if match> MATCH_PCENT:
        return True, match
    else:
        return False, False
    
async def localtime(local):

    # https://stackoverflow.com/questions/4770297/convert-utc-datetime-string-to-local-datetime
    from_zone = tz.gettz("UTC")
    to_zone = tz.gettz("Asia/Kolkata")
    utc = datetime.strptime(str(local), "%Y-%m-%d %H:%M:%S")
    utc = utc.replace(tzinfo=from_zone)
    central = utc.astimezone(to_zone).strftime("%d-%m-%y %I:%M:%S %p")
    return central


async def checkandremove(bot, message):
    media = message.document or message.video or message.audio or message.photo
    message_text = message.caption if media else message.text
    # add more words here inside if necessary
    ignorewords = ["back", "exclusive"]

    #if message_text.lower().startswith(ignorewords):
    # changed algo on req: it now ignores messages with words in ignored words list
    if any(x in message_text.lower() for x in ignorewords):
        return
    
    # handle 0 price products
    zeroprice = ["@0", "@ 0", "rs 0", "rs0"]
    if any(x in message_text.lower() for x in zeroprice):
        await message.delete()
        logger.warning(f"Deleted the post coz it was 0 price \n{message_text}")
        return 

    list_of_links = []

    list_of_links = re.findall(
        "http[s]?://(?:[a-zA-Z]|[0-9]|[$-~_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+",
        message_text,
    )
    
    total_msgs = len(list_of_links)

    can_delmsg = 0
    temp_msg_link = ""
    for link in list_of_links:
        link = await unshorten(link)
        
        if link in LOCALDB:
            oldmsglink = LOCALDB[str(link)]["messagelink"]

            if oldmsglink != message.link:
                can_delmsg += 1
                temp_msg_link = link
                # if not deleted:
                #     await message.delete()
                #     deleted = True
                #     await notify(bot, message, newmsg=message.link, link=link)

                #     logger.info(f"Deleted message\nLink: {message.link}")

        else:
            z = await localtime(message.date)
            LOCALDB[str(link)] = {
                "messagelink": str(message.link),
                "time": str(z)
            }
            asyncio.create_task(removefromlocaldb(link))

            # recheck for link
            # this gonna return 0 if not del, 1 if del
            try:
                can_delmsg += await rechecklink(bot, message, link)
            except:
              can_delmsg += 0
              #logger.error(str(traceback.format_exc()))
              pass
    
    # delete part
    
    if temp_msg_link:
        pcent = (can_delmsg/total_msgs)*100
        if pcent == 100:
            await message.delete()
            await notify(bot, message, newmsg=message.link, link=temp_msg_link)
        else:
            await notify(bot, message,
                newmsg=message.link,
                isdeleted="This message is not deleted",
                link=temp_msg_link, 
                matchpcent=pcent)


async def rechecklink(bot, message, link, recheck=False):
    if "flipkart.com/all/" in link: # ignore these links don't touch it burns
        return 0
    amazonkinda = [
        "amazon.in/promotion/psp/",
        "amazon.in/dp/",
        "amzn.to",
        "a.co",
    ]
    # example https://www.amazon.in/dp/B07J2NGB69/?tag=collab-earticledeal-21&ref=as_li_ss_tl
    # example https://www.amazon.in/promotion/psp/A32VRML0INXWVR?tag=collab-earticledeal-21&ref=as_li_ss_tl
    # example https://amzn.to/3r0dWgf

    flipkartkinda = ["fkrt.it", "flipkart.com", "dl.flipkart.com/dl/", "/p/"]
    # example http://fkrt.it/FDfUc9uuuN
    # example https://dl.flipkart.com/dl/mens-jackets/roadster~brand/pr?&sid=clo,qvw,z0g,jbm&sort=price_asc&p%5B%5D=facets.discount_range_v1%255B%255D=70%2525+or+more&p%5B%5D=facets.fulfilled_by%255B%255D=Plus+%2528FAssured%2529&p%5B%5D=facets.brand%255B%255D=Roadster&affid=inf_d92d3e84-2190-4f28-8a68-4c889e3dd9ca&cmpid=product.share.pp&_refId=PP.2b749a13-e3b9-479d-b16f-6820646edf69.ACCGA5ZXWZGDDANT&_appId=CL
    # example https://www.flipkart.com/kamiliant-american-tourister-kam-triprism-sp-cabin-suitcase-22-inch/p/itm3b198daa88012?affid=inf_2776660f-68cc-43cc-ba54-f0a11e2fd8a0
    
    myntralinks = ["myntra.com"]

    linktypes = amazonkinda + flipkartkinda + myntralinks
    link = link.lower()

    # https://stackoverflow.com/a/3389611/14749365
    if any(x in link for x in linktypes):
        if "?" in link:
            recheck = True
            if "flipkart.com" in link:
                if any(x in link for x in ["flipkart.com/search?&q=", "flipkart.com/search?q="]):
                    if "flipkart.com/search?&q=" in link.lower():
                        k = 2
                    elif "flipkart.com/search?q=" in link.lower():
                        k = 1
                    normallink = "".join(link.split("&")[0:k])
                elif "/p/" in link:
                    normallink = link.split("?")[0] 
                else:
                    normallink = link.replace("https://www.flipkart.com/","")

            elif "myntra.com" in link:
                if "linkredirect.in" in link:
                    parse_result = urlparse(link)
                    dict_result = parse_qs(parse_result.query)
                    normallink = dict_result["dl"][0]
            else:
                normallink = link.split("?")[0]  # only link  non affliated

    if recheck:
        for key, value in LOCALDB.items():
            if any(x in key.lower() for x in linktypes):
                if "?" in key:
                    # special checking for search links
                    if "flipkart.com" in link:
                        if any(x in key for x in ["flipkart.com/search?&q=", "flipkart.com/search?q="]):
                            if "flipkart.com/search?&q=" in key.lower():
                                k = 2
                            elif "flipkart.com/search?q=" in key.lower():
                                k = 1
                            a = "".join(key.split("&")[0:k])
                        elif "/p/" in link:
                            a = key.split("?")[0] 
                        else: 
                            a = key.replace("https://www.flipkart.com/","")
                            normallink = normallink.replace("https://www.flipkart.com/","")
                            q,pcent = similar(normallink,a)
                            if q:
                                if int(pcent) == 100:
                                    return 1
                                #     await message.delete()
                                # await notify(bot,
                                #          message,
                                #          newmsg=message.link,
                                #          isdeleted="This message is not deleted",
                                #          link=key,
                                #          matchpcent=pcent)
                            return 0

                    elif "myntra.com" in key:
                        if "linkredirect.in" in key:
                            parse_result = urlparse(key)
                            dict_result = parse_qs(parse_result.query)
                            real_link = dict_result["dl"][0]  
                            a = real_link.replace("https://www.myntra.com/","")
                            normallink = normallink.replace("https://www.myntra.com/","")
                            q,pcent = similar(normallink,a)   
                            if q:
                                if int(pcent) > 80:
                                    return 1
                                #     await message.delete()
                                # await notify(bot,
                                #          message,
                                #          newmsg=message.link,
                                #          isdeleted="This message is deleted coz it had greater than 80 similarity and its myntra link",
                                #          link=key,
                                #          matchpcent=pcent)
                            return 0
                    else:
                        a = key.split("?")[0]
                        
                    oldmsglink = value["messagelink"]
                    if oldmsglink != message.link:
                        if a == normallink:
                            return 1
                        
                    return 0
                            # await message.delete()
                            # await notify(bot,
                            #              message,
                            #              newmsg=message.link,
                            #              link=key)
                            # return



# bot COdes
@Bot.on_message(filters.command("start"))
async def start_(c, m):
    await m.reply(
        "Bot is online\nCommands are \n/check \nEx: `/check msgidstart`\n\n/limit\nEx:`/limit 100` checks recent 100 msgs\n/set_session\n/set_timing (in seconds)\n/status "
    )


# just checks, deletes, and load not saved links to db
@Bot.on_message(filters.command(["check", "limit"]) & filters.user(AUTH_USERS))
async def check(bot, update):
    if len(update.command) == 1:
        await update.reply(
            "How many recent messages would you like to check for duplicates and remove\nIt should be a messageid from where to star filter or 1 to check all  \nLimit cmd is /limit noofmsgs\n"
        )
        return

    msgscount = int(update.command[1])
    # channel of owner 
    
    usr_session = await db.getSession()
    f_dir = f"download/temp/{update.chat.id}/Usersession/"
    os.makedirs(f_dir, exist_ok=True)
    user_client = Client(
        name="userbot",
        session_string=usr_session,
        api_hash=API_HASH,
        api_id=API_ID,
        workdir=f_dir,
    )

    try:
        await user_client.start()
    except Exception as e:
        return await update.reply(
            text=
            f"#ERROR Failed to user session login\n{e}\n\nGet new session from \nhttps://replit.com/@SpEcHiDe/GenerateStringSession \nRemember need pv2 \n and set it to usr_session in main.py",
            disable_web_page_preview=True,
        )
    logger.info("Client Connected")

    m = await update.reply("Checking for duplicates", True)
    logger.info("Getting messages list")

    all_message_id = []
    if update.command[0] == "limit":
        async for message in user_client.get_chat_history(
                chat_id=int(from_channel[0]), limit=int(msgscount)):
            all_message_id.append(message.id)

    else:
        limit = 10000
        async for message in user_client.get_chat_history(
                chat_id=int(from_channel[0]),
                offset=-1,
                offset_id=int(msgscount) + limit,
                limit=limit,
        ):
            all_message_id.append(message.id)
            if message.id == msgscount:
                break

    all_message_id.reverse()
    logger.info(f"Total messages found to check: {len(all_message_id)}")
    await m.edit(
        f"Total messages to check: {len(all_message_id)}\nStarted Checking\nStay Calm"
    )

    i = 0
    for x in all_message_id:
        message = await bot.get_messages(int(from_channel[0]), int(x))
        await checkandremove(bot, message)
        i += 1
        logger.info(f"Checked {i}/{len(all_message_id)}")

    await m.reply("Done checking ")
    logger.info("Checking 100% done")


# check new posting links
@Bot.on_message(filters.chat(from_channel) & filters.incoming)
async def live_check(bot, message):
    logger.info("#NEw channel message detected")
    await checkandremove(bot, message)


@Bot.on_message(filters.command(["log"]) & filters.user(AUTH_USERS))
async def log_(c, m):
    if os.path.exists("Log.txt"):
        with open("Log.txt", "r") as d_f:
            text = d_f.read()

        await m.reply_document("Log.txt")


@Bot.on_message(filters.command(["set_session"]) & filters.user(AUTH_USERS))
async def set_sess_(bot, message):
    if len(message.command) == 1:
        return await message.reply(
            "use /set_session sessionstring to set \nhttps://replit.com/@SpEcHiDe/GenerateStringSession",
            True,
        )
    a = message.command[1]
    await db.update_session(a)
    await message.reply("Set session success", True)


@Bot.on_message(filters.command(["set_timing"]) & filters.user(AUTH_USERS))
async def set_time_(bot, message):
    if len(message.command) == 1:
        return await message.reply(
            "use /set_timing in_seconds to set\n12hour=43200 ", True)
    a = int(message.command[1])
    await db.update_timing(a)
    await message.reply("Set time success", True)


@Bot.on_message(filters.command(["status"]) & filters.user(AUTH_USERS))
async def status_(bot, message):
    a = await db.getSession()
    b = await db.gettiming()
    await message.reply(f"Session\n{a}\n\nStoretime\n {b}", True)


async def startit():
    # create collections if not exist
    logger.info("Starting Bot")
    await db.createcollection()
    await pyrogram.compose([Bot])


asyncio.run(startit())